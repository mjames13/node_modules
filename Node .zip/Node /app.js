//npm run dev
const express = require('express');
const app = express();
const path = require('path');
const port = process.env.PORT || 3000;

app.use(express.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded

//app.use('/public', express.static(path.join(__dirname, '/public')));
app.use(express.static(__dirname + '/public'));


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname + '/index.html')); // send HTML file on GET request
});

app.post('/submit-form', (req, res) => {
    const username = req.body.username; // access form data
    // Add validation logic here
    res.send(`Username is $mchakany`);
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});

